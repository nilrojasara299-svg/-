import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Sidebar from './components/Sidebar';
import Chatbot from './components/Chatbot';
import Home from './pages/Home';
import Jobs from './pages/Jobs';
import Schemes from './pages/Schemes';
import BackgroundWallpaper from './components/BackgroundWallpaper';

const PageContent: React.FC = () => {
  const location = useLocation();
  return (
    <div key={location.pathname} className="page-transition">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/jobs" element={<Jobs />} />
        <Route path="/schemes" element={<Schemes />} />
        <Route path="/govt-sites" element={<Home />} />
        <Route path="/daily-updates" element={<Home />} />
        <Route path="/about" element={<Home />} />
        <Route path="/contact" element={<Home />} />
        <Route path="/gk" element={<Home />} />
        <Route path="/notifs" element={<Home />} />
      </Routes>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col selection:bg-neon selection:text-deep">
        <BackgroundWallpaper />
        <Header />
        <div className="flex-1 max-w-[1600px] mx-auto w-full flex gap-6 px-4 sm:px-6 lg:px-8 mt-28">
          <Sidebar />
          <main className="flex-1 pb-20 overflow-hidden">
            <PageContent />
          </main>
        </div>
        <Footer />
        <Chatbot />
      </div>
    </Router>
  );
};

export default App;