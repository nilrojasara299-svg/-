
export interface Job {
  id: string;
  title: string;
  department: string;
  location: string;
  lastDate: string;
  link: string;
  advertisementLink: string;
  type: 'New' | 'Direct' | 'Urgent';
  category: string;
}

export interface Scheme {
  id: string;
  title: string;
  description: string;
  category: string;
  benefits: string;
  updatedAt: string;
  image: string;
  applyLink: string;
}

export interface GKQuestion {
  id: string;
  question: string;
  answer: string;
  category: string;
  fact: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
