
import React from 'react';
import GlassCard from '../components/GlassCard';
import { JOBS_DATA } from '../constants';

const Jobs: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-10 font-gujarati animate-in slide-in-from-bottom-10 duration-700">
      <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-white mb-4 tracking-tight">તાજેતરની સરકારી ભરતી ૨૦૨૪</h1>
          <p className="text-slate-400 font-medium text-lg">ગુજરાત સરકાર દ્વારા હાલમાં સક્રિય ૧૫૦+ ભરતીઓની વિગત</p>
        </div>
        <div className="glass-effect px-6 py-3 rounded-2xl flex items-center gap-3 border border-white/10">
          <span className="flex h-3 w-3 rounded-full bg-green-500 animate-pulse"></span>
          <p className="text-sm font-bold text-white"><span className="text-primary text-lg">૪૨</span> સક્રિય પરિણામો મળ્યા</p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-10">
        <aside className="w-full lg:w-80 flex-shrink-0 space-y-8">
          <GlassCard className="border-white/5">
            <h2 className="text-xl font-black mb-6 flex items-center gap-2 text-white">
              <span className="material-symbols-outlined text-primary">filter_list</span> ફિલ્ટર્સ
            </h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest mb-4">નોકરીનો પ્રકાર</h3>
                <div className="space-y-3">
                  {['ક્લાસ ૧-૨', 'ક્લાસ ૩ (બિન-રાજપત્રિત)', 'પોલીસ ભરતી', 'આરોગ્ય વિભાગ'].map(type => (
                    <label key={type} className="flex items-center gap-3 cursor-pointer group">
                      <input type="checkbox" className="rounded bg-slate-800 text-primary focus:ring-primary/20 border-white/10 w-5 h-5" />
                      <span className="text-sm font-bold text-slate-300 group-hover:text-primary transition-colors">{type}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest mb-4">જિલ્લો પસંદ કરો</h3>
                <select className="w-full bg-slate-800/80 border border-white/10 rounded-xl px-4 py-3 text-sm font-bold text-white focus:ring-2 focus:ring-primary outline-none">
                  <option>બધા જિલ્લા</option>
                  <option>અમદાવાદ</option>
                  <option>ગાંધીનગર</option>
                  <option>રાજકોટ</option>
                </select>
              </div>
            </div>
          </GlassCard>
        </aside>

        <div className="flex-1 space-y-6">
          {JOBS_DATA.map(job => (
            <GlassCard key={job.id} className="group border-white/5 hover:-translate-y-1">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="bg-green-500/20 text-green-400 text-[10px] font-black px-3 py-1 rounded-lg uppercase">{job.type}</span>
                    <span className="bg-primary/20 text-primary text-[10px] font-black px-3 py-1 rounded-lg uppercase tracking-wider">{job.category}</span>
                    <div className="flex items-center gap-1 text-primary text-[10px] font-bold">
                       <span className="material-symbols-outlined text-sm">verified</span> Verified Official
                    </div>
                  </div>
                  <h3 className="text-2xl font-black mb-4 leading-tight text-white group-hover:text-primary transition-colors">{job.title}</h3>
                  <div className="flex flex-wrap gap-x-8 gap-y-2 text-sm font-bold text-slate-400">
                    <p className="flex items-center gap-2"><span className="material-symbols-outlined text-lg opacity-60">corporate_fare</span> {job.department}</p>
                    <p className="flex items-center gap-2 text-red-400"><span className="material-symbols-outlined text-lg">calendar_month</span> છેલ્લી તારીખ: {job.lastDate}</p>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 min-w-[220px]">
                  <a 
                    href={job.link} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-1 bg-primary text-white py-3 px-6 rounded-xl font-black shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all text-center text-sm flex items-center justify-center gap-2"
                  >
                    Apply Now <span className="material-symbols-outlined text-sm">open_in_new</span>
                  </a>
                  <a 
                    href={job.advertisementLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 border border-white/10 text-slate-300 py-3 px-6 rounded-xl font-bold hover:bg-white/5 transition-all text-center text-sm"
                  >
                    વિગત જુઓ
                  </a>
                </div>
              </div>
            </GlassCard>
          ))}
          
          <div className="mt-12 flex items-center justify-center gap-3">
            <button className="size-12 rounded-xl border border-white/10 flex items-center justify-center text-slate-500 hover:text-primary hover:border-primary transition-all">
              <span className="material-symbols-outlined">chevron_left</span>
            </button>
            <button className="size-12 rounded-xl bg-primary text-white font-black shadow-lg">1</button>
            <button className="size-12 rounded-xl border border-white/10 flex items-center justify-center text-slate-400 hover:text-primary transition-all font-bold">2</button>
            <button className="size-12 rounded-xl border border-white/10 flex items-center justify-center text-slate-400 hover:text-primary transition-all font-bold">3</button>
            <button className="size-12 rounded-xl border border-white/10 flex items-center justify-center text-slate-500 hover:text-primary hover:border-primary transition-all">
              <span className="material-symbols-outlined">chevron_right</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Jobs;
