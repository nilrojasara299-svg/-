
import React from 'react';
import GlassCard from '../components/GlassCard';
import { SCHEMES_DATA } from '../constants';

const Schemes: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-10 font-gujarati animate-in zoom-in-95 duration-500">
      <div className="mb-12 text-center max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-black text-white mb-6 leading-tight">સરકારી યોજનાઓ - સત્તાવાર માહિતી</h1>
        <p className="text-lg text-slate-400 font-medium leading-relaxed">ગુજરાત અને ભારત સરકારની તમામ જનકલ્યાણકારી યોજનાઓની સાચી અને સરળ સમજૂતી મેળવો.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {SCHEMES_DATA.map(scheme => (
          <GlassCard key={scheme.id} className="flex flex-col border-white/5 p-0 overflow-hidden group">
            <div className="relative h-56 overflow-hidden">
              <img src={scheme.image} alt={scheme.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent"></div>
              <div className="absolute bottom-4 left-4 flex gap-2">
                <span className="bg-primary text-white text-[10px] font-black px-3 py-1 rounded-lg uppercase tracking-widest">{scheme.category}</span>
                <span className="bg-slate-900/80 text-primary text-[10px] font-black px-2 py-1 rounded-lg flex items-center gap-1 shadow-sm border border-white/5">
                  <span className="material-symbols-outlined text-[12px]">verified</span> Govt Portal
                </span>
              </div>
            </div>
            <div className="p-8 flex-1 flex flex-col">
              <h3 className="text-2xl font-black mb-3 text-white group-hover:text-primary transition-colors leading-tight">{scheme.title}</h3>
              <p className="text-slate-400 text-sm mb-6 flex-1 leading-relaxed">{scheme.description}</p>
              <div className="bg-slate-800/50 p-4 rounded-2xl mb-6 border border-white/5">
                <p className="text-xs font-black text-primary uppercase tracking-widest mb-1">લાભ</p>
                <p className="text-sm font-bold text-slate-200 leading-snug">{scheme.benefits}</p>
              </div>
              <div className="space-y-3">
                <a 
                  href={scheme.applyLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-primary text-white py-3 rounded-xl font-black shadow-lg shadow-primary/30 hover:scale-[1.02] active:scale-95 transition-all text-center flex items-center justify-center gap-2"
                >
                  ઓનલાઇન અરજી કરો <span className="material-symbols-outlined text-sm">open_in_new</span>
                </a>
                <div className="flex items-center justify-between pt-4 border-t border-white/5 mt-auto">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">અપડેટ: {scheme.updatedAt}</span>
                  <button className="text-slate-400 font-bold flex items-center gap-1 hover:text-primary transition-colors">વિગત વાંચો <span className="material-symbols-outlined text-base">arrow_forward</span></button>
                </div>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="mt-20 p-12 glass-effect rounded-[3rem] text-center border-white/10 shadow-2xl shadow-primary/10">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-black text-white mb-6">કોઈ ચોક્કસ યોજના વિશે પ્રશ્ન છે?</h2>
          <p className="text-slate-400 mb-8 font-medium">અમારો AI ચેટબોટ તમને ૧૦૦% સાચી માહિતી સેકન્ડોમાં આપશે. અત્યારે જ વાત કરો!</p>
          <button className="bg-primary text-white px-10 py-5 rounded-2xl font-black shadow-xl shadow-primary/20 hover:scale-105 active:scale-95 transition-all">
            AI ચેટ શરૂ કરો
          </button>
        </div>
      </div>
    </div>
  );
};

export default Schemes;
