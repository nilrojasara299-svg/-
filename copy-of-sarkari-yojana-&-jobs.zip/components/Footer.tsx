
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="mt-20 border-t border-white/10 py-16 px-4 font-gujarati bg-slate-900/50 backdrop-blur-md">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-1">
          <div className="flex items-center gap-3 mb-6">
            <div className="size-10 bg-primary rounded-xl flex items-center justify-center text-white">
              <span className="material-symbols-outlined text-2xl">hub</span>
            </div>
            <h2 className="text-xl font-black text-white">સરકારી પોર્ટલ</h2>
          </div>
          <p className="text-slate-400 text-sm leading-relaxed mb-6">
            ગુજરાત સરકારની તમામ સત્તાવાર યોજનાઓ અને ભરતીની માહિતી આપતું વિશ્વસનીય પોર્ટલ.
          </p>
          <div className="flex gap-4">
            {['facebook', 'chat', 'alternate_email'].map((icon) => (
              <button key={icon} className="size-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-all shadow-sm border border-primary/20">
                <span className="material-symbols-outlined text-xl">{icon}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-bold text-white mb-6">મહત્વની શ્રેણીઓ</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            {['નવી ભરતી ૨૦૨૪', 'શિક્ષણ સહાય', 'ખેતીવાડી યોજનાઓ', 'પરીક્ષા પરિણામો'].map(link => (
              <li key={link} className="hover:text-primary cursor-pointer transition-colors flex items-center gap-2">
                <span className="material-symbols-outlined text-xs">arrow_forward</span> {link}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white mb-6">મદદ અને સપોર્ટ</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            {['વારંવાર પૂછાતા પ્રશ્નો', 'સંપર્ક કરો', 'પ્રાઇવસી પોલિસી', 'નિયમો અને શરતો'].map(link => (
              <li key={link} className="hover:text-primary cursor-pointer transition-colors flex items-center gap-2">
                <span className="material-symbols-outlined text-xs">arrow_forward</span> {link}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white mb-6">સબ્સ્ક્રાઇબ કરો</h4>
          <p className="text-sm text-slate-400 mb-4">લેટેસ્ટ અપડેટ્સ માટે તમારા ઇમેઇલ સાથે જોડાઓ.</p>
          <div className="flex gap-2">
            <input type="email" placeholder="ઇમેઇલ..." className="flex-1 bg-slate-800 border-white/10 rounded-xl px-4 py-2 text-sm text-white focus:ring-primary focus:border-primary" />
            <button className="bg-primary text-white px-4 py-2 rounded-xl font-bold text-xs hover:scale-105 transition-all">જોડાઓ</button>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-bold text-slate-500 uppercase tracking-widest">
        <p>© ૨૦૨૪ સરકારી પોર્ટલ. સર્વાધિકાર સુરક્ષિત.</p>
        <div className="flex gap-8">
          <span className="hover:text-primary cursor-pointer transition-colors">TELEGRAM</span>
          <span className="hover:text-primary cursor-pointer transition-colors">WHATSAPP</span>
          <span className="hover:text-primary cursor-pointer transition-colors">TWITTER</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
