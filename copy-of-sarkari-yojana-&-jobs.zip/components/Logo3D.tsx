import React from 'react';

const Logo3D: React.FC = () => {
  return (
    <div className="relative group cursor-pointer">
      <svg width="48" height="48" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-2xl">
        <defs>
          <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00F2FF" />
            <stop offset="100%" stopColor="#4F46E5" />
          </linearGradient>
          <filter id="neon-glow-filter">
            <feGaussianBlur stdDeviation="1.5" result="coloredBlur"/>
            <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          <filter id="inner-shadow">
            <feOffset dx="2" dy="2" />
            <feGaussianBlur stdDeviation="2" />
            <feComposite operator="out" in="SourceGraphic" result="inverse" />
            <feFlood floodColor="black" floodOpacity="0.5" result="color" />
            <feComposite operator="in" in="color" in2="inverse" result="shadow" />
            <feComposite operator="over" in="shadow" in2="SourceGraphic" />
          </filter>
        </defs>
        {/* Glow behind logo */}
        <circle cx="50" cy="50" r="40" fill="#00F2FF" fillOpacity="0.1" />
        
        <rect x="15" y="15" width="70" height="70" rx="22" fill="url(#logoGrad)" filter="url(#inner-shadow)" className="transition-all duration-500 group-hover:rotate-6" />
        <path d="M50 30L72 50L50 70L28 50L50 30Z" fill="white" fillOpacity="0.9" className="animate-pulse" />
        <circle cx="50" cy="50" r="6" fill="#020617" />
        <circle cx="50" cy="50" r="3" fill="#00F2FF" filter="url(#neon-glow-filter)" />
      </svg>
      <div className="absolute -inset-1 bg-neon/30 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
    </div>
  );
};

export default Logo3D;