
import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Sidebar: React.FC = () => {
  const location = useLocation();
  const menuItems = [
    { icon: 'home', name: 'મુખ્ય પેજ', path: '/' },
    { icon: 'work', name: 'નવી ભરતી', path: '/jobs' },
    { icon: 'description', name: 'યોજનાઓ', path: '/schemes' },
    { icon: 'public', name: 'સરકારી સાઇટ્સ', path: '/govt-sites' },
    { icon: 'history', name: 'ડેઇલી અપડેટ', path: '/daily-updates' },
    { icon: 'menu_book', name: 'જનરલ નોલેજ', path: '/gk' },
  ];

  return (
    <aside className="hidden xl:flex flex-col w-64 h-[calc(100vh-120px)] sticky top-24 gap-4 px-2 font-gujarati">
      <div className="clay-card p-4 flex flex-col gap-2 border-neon/5">
        <h3 className="text-[10px] font-black text-slate-600 uppercase tracking-widest px-4 mb-2">મેનુ નેવિગેશન</h3>
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-300 relative group overflow-hidden ${
                isActive
                  ? 'bg-primary/20 text-neon shadow-neon/10 border border-neon/20'
                  : 'text-slate-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <span className={`material-symbols-outlined text-xl ${isActive ? 'text-neon animate-pulse' : 'opacity-60 group-hover:opacity-100'}`}>
                {item.icon}
              </span>
              <span className="text-sm font-bold">{item.name}</span>
              {isActive && (
                 <div className="absolute right-2 size-1.5 rounded-full bg-neon shadow-neon"></div>
              )}
            </Link>
          );
        })}
      </div>

      <div className="clay-card p-5 flex flex-col gap-4 mt-2 bg-gradient-to-br from-secondary/10 via-transparent to-transparent border-secondary/10">
        <div className="flex items-center gap-3">
          <div className="size-8 rounded-lg bg-secondary/20 flex items-center justify-center text-secondary">
            <span className="material-symbols-outlined text-xl">trending_up</span>
          </div>
          <h3 className="text-xs font-black text-white uppercase tracking-wider">ટ્રેન્ડિંગ ટોપિક્સ</h3>
        </div>
        <ul className="space-y-2.5">
          {['તલાટી મેરીટ ૨૦૨૪', 'LRD રિઝલ્ટ લિંક', 'વહાલી દીકરી યોજના'].map((tag) => (
            <li key={tag} className="text-[11px] font-bold text-slate-400 hover:text-secondary cursor-pointer flex items-center gap-2 transition-colors">
              <span className="material-symbols-outlined text-[10px]">arrow_forward_ios</span> {tag}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-auto px-4 py-2">
        <p className="text-[9px] font-black text-slate-600 text-center uppercase tracking-widest">Version 3.0.0 Neon Hub</p>
      </div>
    </aside>
  );
};

export default Sidebar;
