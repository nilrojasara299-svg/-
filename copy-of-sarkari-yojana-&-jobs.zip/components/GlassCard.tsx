
import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
}

const GlassCard: React.FC<GlassCardProps> = ({ children, className = "" }) => {
  return (
    <div className={`glass-effect rounded-3xl p-6 shadow-2xl transition-all duration-300 ${className}`}>
      {children}
    </div>
  );
};

export default GlassCard;
