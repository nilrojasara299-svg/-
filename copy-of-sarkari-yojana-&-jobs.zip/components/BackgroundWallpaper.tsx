import React from 'react';

const BackgroundWallpaper: React.FC = () => {
  return (
    <div className="fixed inset-0 -z-20 overflow-hidden pointer-events-none opacity-5">
      {/* Decorative Stationary SVGs in Wallpaper style */}
      <div className="absolute top-[10%] left-[5%] animate-pulse opacity-40">
        <span className="material-symbols-outlined text-[150px] text-primary rotate-12">menu_book</span>
      </div>
      <div className="absolute top-[40%] right-[10%] animate-bounce opacity-30" style={{ animationDuration: '6s' }}>
        <span className="material-symbols-outlined text-[120px] text-secondary -rotate-12">edit_note</span>
      </div>
      <div className="absolute bottom-[10%] left-[15%] animate-pulse opacity-40">
        <span className="material-symbols-outlined text-[180px] text-neon rotate-45">school</span>
      </div>
      <div className="absolute top-[20%] left-[40%] opacity-20">
        <span className="material-symbols-outlined text-[100px] text-slate-400 -rotate-45">ink_pen</span>
      </div>
      <div className="absolute bottom-[20%] right-[30%] animate-bounce opacity-30" style={{ animationDuration: '8s' }}>
        <span className="material-symbols-outlined text-[140px] text-accent">history_edu</span>
      </div>
    </div>
  );
};

export default BackgroundWallpaper;