
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

export class AIHandler {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: API_KEY || '' });
  }

  async getResponse(prompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          ...history,
          { role: 'user', parts: [{ text: prompt }] }
        ],
        config: {
          systemInstruction: "You are a helpful assistant for a Gujarat Government Job and Schemes portal. Provide accurate information about jobs, schemes, and competitive exams in Gujarati or English as requested. Keep it friendly and concise.",
        }
      });
      return response.text;
    } catch (error) {
      console.error("AI Error:", error);
      return "માફ કરશો, અત્યારે સર્વરમાં ખામી છે. કૃપા કરીને થોડા સમય પછી પ્રયત્ન કરો.";
    }
  }
}

export const aiHandler = new AIHandler();
