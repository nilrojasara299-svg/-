
import React from 'react';
import { Job, Scheme, GKQuestion } from './types';

export const JOBS_DATA: Job[] = [
  {
    id: '1',
    title: 'Bin Sachivalay Clerk & Office Assistant',
    department: 'GSSSB',
    location: 'Across Gujarat',
    lastDate: '15/11/2024',
    link: 'https://ojas.gujarat.gov.in/Apply.aspx',
    advertisementLink: 'https://ojas.gujarat.gov.in/AdvtList.aspx?type=l96769786975',
    type: 'New',
    category: 'Class 3'
  },
  {
    id: '2',
    title: 'GPSC Class 1 & 2 Officers',
    department: 'GPSC',
    location: 'Gandhinagar',
    lastDate: '30/10/2024',
    link: 'https://gpsc-ojas.gujarat.gov.in/Apply.aspx',
    advertisementLink: 'https://gpsc-ojas.gujarat.gov.in/AdvtDetailFiles/GPSC_202425_1.pdf',
    type: 'Direct',
    category: 'Class 1-2'
  },
  {
    id: '3',
    title: 'Police Constable & LRD',
    department: 'Gujarat Police',
    location: 'Across Gujarat',
    lastDate: '25/11/2024',
    link: 'https://ojas.gujarat.gov.in/Apply.aspx',
    advertisementLink: 'https://ojas.gujarat.gov.in/AdvtList.aspx?type=l91769186915',
    type: 'Urgent',
    category: 'Police'
  }
];

export const SCHEMES_DATA: Scheme[] = [
  {
    id: '1',
    title: 'PM Kisan Samman Nidhi',
    description: 'Direct financial assistance to farmers of ₹6,000 per year.',
    category: 'Agriculture',
    benefits: 'Financial help to small farmers',
    updatedAt: '12 Aug 2024',
    image: 'https://picsum.photos/seed/farm/400/300',
    applyLink: 'https://pmkisan.gov.in/RegistrationFormNew.aspx'
  },
  {
    id: '2',
    title: 'Ayushman Card (PMJAY)',
    description: 'Health insurance up to ₹10 Lakhs for families.',
    category: 'Health',
    benefits: 'Free hospital treatment',
    updatedAt: '10 Aug 2024',
    image: 'https://picsum.photos/seed/health/400/300',
    applyLink: 'https://beneficiary.nha.gov.in/'
  },
  {
    id: '3',
    title: 'Vahli Dikri Yojana',
    description: 'Incentive-based scheme for girls from birth to higher education.',
    category: 'Education',
    benefits: 'Financial aid for marriage and education',
    updatedAt: '15 Aug 2024',
    image: 'https://picsum.photos/seed/girl/400/300',
    applyLink: 'https://www.digitalgujarat.gov.in/'
  }
];

export const GK_DATA: GKQuestion[] = [
  {
    id: '1',
    question: 'ગુજરાતના પ્રથમ મહિલા મુખ્યમંત્રી કોણ હતા?',
    answer: 'આનંદીબેન પટેલ',
    category: 'ઇતિહાસ',
    fact: 'તેઓ ૨૦૧૪ થી ૨૦૧૬ સુધી પદ પર રહ્યા હતા.'
  },
  {
    id: '2',
    question: 'કિર્તી મંદિર કયા શહેરમાં આવેલું છે?',
    answer: 'પોરબંદર',
    category: 'ભૂગોળ',
    fact: 'આ ગાંધીજીનું જન્મસ્થળ છે.'
  }
];
